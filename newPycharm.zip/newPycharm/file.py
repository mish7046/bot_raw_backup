
from time import sleep
a = 0
b = ''
c = []
sleep(5)
a = int(input('a: '))
b = input('b: ')
c.append(input('c: '))
print(a, b, c[0])
