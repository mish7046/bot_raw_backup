from PIL import ImageFont, ImageDraw, Image
import math
import re


def pic_gen(message, author, may_save):

    for every in re.findall('\s+', message):
        message = message.replace(every, ' ')
    message = list(message)
    for i in range(1, math.ceil(len(message) / 45)):
        message.insert(i * 45, '\n')
    msg = ''.join(message)
    msg.strip()
    # print(len(msg), '\n', msg)
    temp = Image.new('RGB', (512, 256), (25, 25, 25, 255))
    fnt = ImageFont.truetype('font.ttf', 20)

    d = ImageDraw.Draw(temp)
    d.text((20, 25), msg, font=fnt, fill=(255, 255, 255, 255))
    d.text((280, 220), '(c) ' + author, font=fnt, fill=(255, 255, 255, 255))
    if may_save:
        temp.save('cit.jpeg', format='jpeg')
    else:
        return temp


# Хм         хм         хм       хм\n   Хм   хм         хм хм   хм\n      Хм             хм  хм   хм \n   Хм   хм       хм    хм хм\nХм         хм   хм      хм   хм
