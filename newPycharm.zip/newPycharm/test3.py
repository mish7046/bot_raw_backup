import vk_api.vk_api
import vk_api.bot_longpoll as vkb
import time
import json


def write(msg):
    vk.method('messages.send', {'peer_id': event.obj['peer_id'],
                                'random_id': round(time.time() * 100000),
                                'message': msg})


def private_write(uid, message):
    vk.method('messages.send', {'user_id': uid,
                                'message': message,
                                'random_id': round(time.time()*100000),
                                'group_id': gr_id})


ac_token = '4549d1daeec67cc1b9e2ed2dc2beb60aebca8f626ed4732d5bffa362d9556a3ace3be4a16f725f013d55e'
vk = vk_api.VkApi(token=ac_token)
gr_id = 184364262
longpoll = vkb.VkBotLongPoll(vk, gr_id)

for event in longpoll.listen():
    if event.type == vkb.VkBotEventType.MESSAGE_NEW:

        print(event.obj)
        if event.obj.peer_id != event.obj.from_id:
            if event.obj['text'] == '1':
                vk.method('messages.send', {'peer_id': event.obj['peer_id'],
                                            'random_id': round(time.time() * 100000),
                                            'message': 'hello, chat'})
                time.sleep(12)
            elif event.obj['text'] == '2':
                write('я не сплю!')

            elif event.obj['text'].startswith('[club184364262|'):
                write('меня вызвал ' + str(event.obj['from_id']))  # s

            elif event.obj['text'] == '3':
                vk.method('messages.send', {
                        'peer_id': event.obj['peer_id'],
                        'random_id': round(time.time() * 100000),
                        'message': 'Клавиатура убрана',
                        'keyboard': json.dumps({"one_time": True, "buttons": []})
                    })
            elif event.obj.get('action') is not None:
                if event.obj['action']['type'] == 'chat_invite_user':
                    try:
                        private_write(event.obj['action']['member_id'], 'о привет ты новенький тебе бан')
                    except vk_api.ApiError:
                        write('Вам необходимо разрешить сообщения от сообщества vk.com/club'+str(gr_id))

        if event.obj.peer_id == event.obj.from_id:
            if event.obj['text'] == '1':
                write('hello, user')
# {'date': 1562869867, 'from_id': 304844829, 'id': 0, 'out': 0, 'peer_id': 2000000001, 'text': '', 'conversation_message_id': 686, 'action': {'type': 'chat_kick_user', 'member_id': 195435608}, 'fwd_messages': [], 'important': False, 'random_id': 0, 'attachments': [], 'is_hidden': False}
