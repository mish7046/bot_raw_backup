# import requests

app_id = '7053864'
scope = 'offline,groups'
secure_key = '2dDaV6Kt7VhyV6uxAo3l'
access_token = '80481299fbaa827c1a7915043a1757420ed141b8df866d6d2ebafb2497a0c0adb8c7e1c8c8cd17416e2c9'
service_key = '3b75909a3b75909a3b75909a743b1e32b233b753b75909a665da8fb7182cd97112c3d86'
first_req = 'https://oauth.vk.com/authorize?client_id='+app_id+'&display=page&redirect_uri=https://oauth.vk.com/blank.html&scope='+scope+'&response_type=token&v=5.95"'
print(first_req)
