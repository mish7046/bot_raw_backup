arr = []
i = 0
while i < 4:
    n = input("inp: ")
    arr.append(n[:].split(" "))
    i += 1
print(arr)
