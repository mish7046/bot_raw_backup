import vk_api.vk_api
import vk_api.bot_longpoll as vkb
import time
import json
import random


def write(msg):
    vk.method('messages.send', {'peer_id': event.obj['peer_id'],
                                'random_id': round(time.time() * 100000),
                                'message': msg})


def matches(obj, lst):
    for item in lst:
        if obj == item:
            return True
    return False


def mul_send_kbrd(kbrd_values, uid, index):
    btns = [[{"action": {"type": "text", "label": 'ответ:' + kbrd_values[index][2]}, "color": "primary"}],
            [{"action": {"type": "text", "label": 'ответ:' + kbrd_values[index][3]}, "color": "primary"}],
            [{"action": {"type": "text", "label": 'ответ:' + kbrd_values[index][4]}, "color": "primary"}]]
    random.shuffle(btns)
    vk.method('messages.send', {'user_id': uid,
                                'message': kbrd_values[index][1],
                                'random_id': round(time.time() * 100000),
                                'keyboard':  json.dumps({"one_time": False, "buttons": btns})
                                })


def private_write(uid, message):
    vk.method('messages.send', {'user_id': uid,
                                'message': message,
                                'random_id': round(time.time()*100000),
                                'group_id': group_id})


ac_token = '1e6284c20946332e3177d279b61b222f8caae6521b82a41122c80117f35a61cf99578cc1f209342aee447'
vk = vk_api.VkApi(token=ac_token)
group_id = 183806846
chat_id = 0
longpoll = vkb.VkBotLongPoll(vk, group_id)
flag_kbrd = False
flag_add_qa = False
admins = open('admins.txt', 'r').read().split(',')
# s 482925815,
cmd = ['добавить вопрос', 'отменить ввод', 'записать последовательность вопросов', 'существующие вопросы', 'дать доступ', 'вопрос', 'помощь']
buttons = []
qa = []
seq = []
temp_q = []
user_indices = {}
qa_cnt = 0
qa_times = 0
rand = 0

for event in longpoll.listen():
    if event.type == vkb.VkBotEventType.MESSAGE_NEW:

        print('GLOBAL: ' + str(event.obj))
        if event.obj.peer_id != event.obj.from_id:
            if event.obj['text'] == '1':
                vk.method('messages.send', {'peer_id': event.obj['peer_id'],
                                            'random_id': round(time.time() * 100000),
                                            'message': 'hello, chat'})

            elif event.obj.get('action') is not None:
                if event.obj['action']['type'] == 'chat_invite_user':
                    try:
                        with open('seq.txt', 'r') as cf:
                            for string in cf.readlines():
                                if string.startswith('1'):
                                    seq = string.split('/')
                            seq.remove(seq[0])
                            seq.remove(seq[len(seq) - 1])
                            # print(seq)
                        with open('qaa.txt', 'r') as quests:
                            for l in seq:
                                # print(l)
                                # print(quests.readlines()[int(l) - 1:int(l)])
                                quests.seek(0, 0)
                                qa.append(quests.readlines()[int(l) - 1:int(l)][0].split('($)'))
                        print(qa)
                        if user_indices.get(event.obj['action']['member_id']) is None:
                            user_indices.update(dict.fromkeys([event.obj['action']['member_id'], 0]))
                        mul_send_kbrd(qa, event.obj['action']['member_id'], user_indices[event.obj['action']['member_id']])
                        chat_id = event.chat_id
                        flag_kbrd = True
                    except vk_api.ApiError:
                        write('Вам необходимо разрешить сообщения от сообщества vk.com/club'+str(group_id))

            if event.obj['text'] == '3':
                vk.method('messages.send', {'peer_id': event.obj['peer_id'],
                                            'random_id': round(time.time() * 100000),
                                            'message': 'Клавиатура убрана',
                                            'keyboard': json.dumps({"one_time": True, "buttons": []})
                                            })

        if event.obj.peer_id == event.obj.from_id:
            if event.obj['text'] == '1':
                write('hello, user')
                print(admins)
            # _________________________
            # ---===ADMIN SECTION===---
            # _________________________
            elif event.obj['text'] == 'команды':
                write(', '.join(cmd))

            elif event.obj['text'].lower() == cmd[4]:
                if matches(str(event.obj['peer_id']), admins):
                    flag_add_qa = True
                    write('Вы админ, доступ к командам разрешен')
                else:
                    write('Вы не администратор, доступ запрещен')

            elif event.obj['text'].lower() == cmd[0]:
                if flag_add_qa is True:
                    write('введите вопрос(ы) по шаблону: \nследующий номер вопроса##вопрос##правильный ответ##неправильный ответ 1##неправильный ответ 2\nвведите "отменить ввод" для отмены')
                    with open('qaa.txt', 'r') as q:
                        for i in q.readlines():
                            qa_cnt += 1
                        write('номер последнего введенного вопроса - ' + str(qa_cnt))
                        qa_cnt = 0
                        write('Важно! Номера(индексы) вопросов должны следовать по порядку(1,2,3,4 и т.д.)')
                else:
                    write('Вы не админ или не ввели команду "добавить вопрос"')

            elif event.obj['text'].lower() == cmd[1] and flag_add_qa is True:
                    flag_add_qa = False
                    write('ввод отменен')

            elif event.obj['text'].find('##') > 0 and flag_add_qa is True:
                if len(event.obj['text'].split('##')) < 5:
                    write('введенные данные некорректны, проверьте кол-во разделителей')
                else:
                    converted_string = event.obj['text'].replace('##', '($)')+'($)\n'
                    with open('qaa.txt', 'a+') as f:
                        f.write(converted_string)
                        flag_add_qa = False
                        write('Ваш вопрос записан!')

            elif event.obj['text'].find('##') == 0 and flag_add_qa is True:
                write('Введенные данные некорректны. Вы действительно ввели вопрос?')

            elif event.obj['text'].lower() == cmd[2] and flag_add_qa is True:
                write('Напишите номер следующей последовательности, \n'
                      'а затем "/" и последовательность из номеров(индексов) вопросов, разделенных символом "/"\nНапример, "5/1/3/2/4. Здесь'
                      '5 - это номер(индекс) последовательности, а 1, 3, 2, 4 - номера(индексы) вопросов')

            elif event.obj['text'].lower() == cmd[3] and flag_add_qa is True:
                with open('qaa.txt', 'r') as ff:
                    write(ff.read().replace('($)', '; '))

            elif event.obj['text'].find('/') > 0 and flag_add_qa is True:
                with open('seq.txt', 'a+') as s:
                    s.write(event.obj['text']+'/\n')
                    write('Последовательность успешно записана!')
            # ________________________________
            # ---===END OF ADMIN SECTION===---
            # ________________________________
            # ---===USER SECTION===---
            # ________________________
            elif flag_kbrd and event.obj['text'].startswith('ответ:'):
                if event.obj['text'].split(':')[1] == qa[user_indices[event.obj['peer_id']]][2]:
                    write('правильно')
                    user_indices[event.obj['peer_id']] += 1
                    flag_kbrd = False
                else:
                    vk.method('messages.removeChatUser', {'chat_id': chat_id,
                                                          'member_id': event.obj['peer_id']
                                                          })
                    flag_kbrd = False
                    user_indices.pop()

            if event.obj['text'] == '3':
                vk.method('messages.send', {'peer_id': event.obj['peer_id'],
                                            'random_id': round(time.time() * 100000),
                                            'message': 'Клавиатура убрана',
                                            'keyboard': json.dumps({"one_time": True, "buttons": []})
                                            })

# https://vk.com/app7053830_-183806846  [257885296, 280504170, 195435608, 225533970, 482925815, 304844829, 316504955]
