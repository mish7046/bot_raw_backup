import vk_api.vk_api
import vk_api.bot_longpoll as vkb
import time
from img import pic_gen
import random
import json
# photo482925815_456249022


def write(uid, raw_msg):
        vk.method('messages.send', {'peer_id': uid,
                                    'random_id': round(time.time() * 100000),
                                    'message': raw_msg})


def send_att(uid, attachment_id):
    vk.method('messages.send', {'peer_id': uid,
                                'random_id': round(time.time() * 100000),
                                'attachment': attachment_id})


def mul_replace(base_string, array_old, new):
    for item in base_string:
        for match in array_old:
            if item == match:
                base_string = base_string.replace(match, new)
    return base_string


def match_str(check_val, first_part, arg_list, ret):
    for items in arg_list:
        if items+first_part == check_val:
            if ret:
                return True
            else:
                return arg_list[items]


def get_msgs_ids(pid, hist):
    items = []
    ids = []
    for obj in hist:
        if pid == obj['peer_id']:
            items.append(obj)
    for selected in items:
        ids.append(selected['conversation_message_id'])
    ids.reverse()
    return ids


ac_token = 'c40ed8364b1fbd0bc1e4a753c25529c8f08258e1e8aad38627cded28a94560ec21c5b92be525af1af5a4f'
cmd = ['справедливо', 'чан говна', 'казино', 'удоли', 'говновоз говна', 'спгв', 'чан чая']
deleted_data = ['кокс', 'ВАГОН КОКСА', 'культ', 'печенька из BRAZZERS', 'ну удалены так удалены', 'синусоидная нора', 'бан', 'тряяпочка!', 'скалярное оружие', 'феатуред', 'апвоут']
rubbish = ['[', ']', '\'', '"', '{', '}', ',']
prefix = {'': 87, 'кило': 88, 'мега': 89, 'гига': 90}
photos_links = ['photo-182022767_456239019', 'photo-182022767_456239020', 'photo-182022767_45623902', 'photo-182022767_456239080']
hist_chat = []
hist_user = []
album_id = 262936357
group_id = 182022767
pid_pref = 2000000000
last_id = 0
photo_base = 'photo-182022767_4562390'

vk = vk_api.VkApi(token=ac_token)
longpoll = vkb.VkBotLongPoll(vk, 182022767)

for event in longpoll.listen():
    if event.type == vkb.VkBotEventType.MESSAGE_NEW:

        if event.obj.peer_id != event.obj.from_id:
            print(event.obj)
            hist_chat.append(event.obj)
            r = random.randrange(1, 4)
            if event.obj['text'] == '1':
                write(event.obj['peer_id'], 'hello, chat')
            elif event.obj['text'].lower() == 'команды':
                write(event.obj['peer_id'], ', '.join(cmd))
            elif event.obj['text'].lower() == cmd[0]:
                vk.method('messages.send', {'peer_id': event.obj['peer_id'],
                                            'random_id': round(time.time() * 100000),
                                            'sticker_id': 163})
            elif event.obj['text'].lower().find(cmd[1]) > -1:
                send_att(event.obj['peer_id'], photos_links[0])

            elif event.obj['text'].lower().find(cmd[2]) > -1:
                send_att(event.obj['peer_id'], 'video1016882_167645119')

            elif event.obj['text'].lower().find(cmd[4]) > -1:
                send_att(event.obj['peer_id'], photos_links[1])

            elif event.obj['text'].lower().find(cmd[5]) > -1:
                send_att(event.obj['peer_id'], photos_links[2] + str(r))

            elif event.obj['text'].lower().find(cmd[6]) > -1:
                send_att(event.obj['peer_id'], photos_links[3])

            elif event.obj['text'].lower().find('данные удалены') > -1:
                write(event.obj['peer_id'], deleted_data[random.randrange(0, 11)])

            elif event.obj['text'].lower() == 'торговля':
                write(event.obj['peer_id'], 'Ты б еще консервных банок принес!')

            elif event.obj['text'].lower() == 'шмет':
                send_att(event.obj['peer_id'], str(photo_base+str(random.choice([random.randrange(91, 96), 99]))))

            elif match_str(event.obj['text'], 'шмет', prefix, True):
                send_att(event.obj['peer_id'], photo_base+str(match_str(event.obj['text'], 'шмет', prefix, False)))

            elif event.obj['text'] == '2' and event.obj['fwd_messages'] is not '':
                try:
                    msg = event.obj['fwd_messages'][0]['text']
                    author = mul_replace(str(list(vk.method('users.get', {'user_ids': event.obj['fwd_messages'][0]['from_id']})[0].values())[1: 3]), rubbish, '')
                    pic_gen(msg, author, True)
                    vk_upload = vk_api.upload.VkUpload(vk)
                    r = vk_upload.photo_messages('cit.jpeg')
                    photo = 'photo'+str(r[0]['owner_id'])+'_'+str(r[0]['id'])
                    send_att(event.obj['peer_id'], photo)
                    print(photo)
                except vk_api.ApiError:
                    print('exception occured')
                    pass
                except IndexError:
                    print('exception occured')
                    pass

            elif event.obj['text'] == '3':
                lst = get_msgs_ids(event.obj['peer_id'], hist_chat)
                # print(lst)
                print(json.dumps(lst, indent=2))
                i = 1
                while i < len(lst):
                    if lst[i-1] - lst[i] > 1:
                        print('id N: ', [lst[i]+1])
                        vk.method('messages.delete', {
                                                     'message_ids': [lst[i]+1],
                                                     # 'group_id': group_id,
                                                     'delete_for_all': 1,
                                                     })
                        i = len(lst)
                    i = i + 1

            print('-' * 30)

        if event.obj.peer_id == event.obj.from_id:
            hist_user.append(event.obj)
            if event.obj['text'] == '1':
                write(event.obj['peer_id'], 'hello, user')
                print(event.obj)
                print('-' * 30)
